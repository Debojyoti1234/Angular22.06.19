package com.cg.bookstore.beans;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
@Entity
public class Category {
	


	@Id
	private int categoryId;

	private String categoryName;

	@OneToMany(mappedBy = "category", targetEntity = Books.class)
	private List<Books> book;

	public Category() {	}

	public Category(int categoryId, String categoryName, List<Books> book) {
		super();
		this.categoryId = categoryId;
		this.categoryName = categoryName;
		this.book = book;
	}

	public int getCategoryId() {
		return categoryId;
	}

	public void setCategoryId(int categoryId) {
		this.categoryId = categoryId;
	}

	public String getCategoryName() {
		return categoryName;
	}

	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}

	public List<Books> getBook() {
		return book;
	}

	public void setBook(List<Books> book) {
		this.book = book;
	}


}
